import { MAX_TOKEN_BYTES } from "./protocol.ts";
import { pointer } from "./schema.ts";
import type { ConfigIssue, Limits } from "./types.ts";

/** The longest delay setTimeout honors. */
const MAX_TIMER_MS = 2_147_483_647;

/** Room for the Socket.IO CONNECT frame around a token at MAX_TOKEN_BYTES (packet type, JSON keys, protocolVersion). */
const MIN_CONTROL_FRAME_BYTES = MAX_TOKEN_BYTES + 1_024;

/** Starting bounds from the specification; not published capacity claims. */
export const DEFAULT_LIMITS: Readonly<Limits> = Object.freeze({
  maxConnections: 1_000,
  maxSubscriptionsPerConnection: 50,
  maxSourceRecordBytes: 1_048_576,
  maxDataFrameBytes: 65_536,
  maxParamsBytes: 4_096,
  maxPendingFramesPerSubscription: 100,
  maxPendingBytesPerSubscription: 1_048_576,
  maxPendingBytesPerConnection: 4_194_304,
  maxPendingBytesGateway: 67_108_864,
  maxMapOutputs: 100,
  maxConcurrentSnapshots: 32,
  handlerTimeoutMs: 2_000,
  snapshotTimeoutMs: 10_000,
  receiptTimeoutMs: 5_000,
  maxSyncAttempts: 3,
  maxTraceEntries: 10_000,
  maxTraceBytes: 8_388_608,
  maxControlFrameBytes: 16_384,
  controlRequestsPerSecond: 20
});

export const LIMIT_KEYS = Object.keys(DEFAULT_LIMITS) as readonly (keyof Limits)[];

export function resolveLimits(overrides: Partial<Limits> | undefined): Limits {
  return { ...DEFAULT_LIMITS, ...(overrides ?? {}) };
}

/** Validates override values and cross-field consistency of the resolved limits. */
export function validateLimits(input: unknown, path: string, issues: ConfigIssue[]): void {
  if (input === undefined) return;
  if (typeof input !== "object" || input === null || Array.isArray(input)) {
    issues.push({ path, code: "INVALID_TYPE", message: "limits must be an object." });
    return;
  }
  const overrides: Partial<Limits> = {};
  let valid = true;
  for (const [key, value] of Object.entries(input)) {
    if (!(LIMIT_KEYS as readonly string[]).includes(key)) {
      issues.push({ path: pointer(path, key), code: "UNKNOWN_KEY", message: `Unknown limit "${key}".` });
      valid = false;
      continue;
    }
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value <= 0) {
      issues.push({ path: pointer(path, key), code: "INVALID_VALUE", message: `${key} must be a positive integer.` });
      valid = false;
      continue;
    }
    // Node clamps a longer timer to 1 ms, so such a timeout would fire at once.
    if (key.endsWith("Ms") && value > MAX_TIMER_MS) {
      issues.push({ path: pointer(path, key), code: "INVALID_VALUE", message: `${key} must be at most ${MAX_TIMER_MS} (about 24.8 days).` });
      valid = false;
      continue;
    }
    overrides[key as keyof Limits] = value;
  }
  if (!valid) return;
  const limits = resolveLimits(overrides);
  const ordered: [keyof Limits, keyof Limits][] = [
    ["maxDataFrameBytes", "maxPendingBytesPerSubscription"],
    ["maxPendingBytesPerSubscription", "maxPendingBytesPerConnection"],
    ["maxPendingBytesPerConnection", "maxPendingBytesGateway"],
    ["maxParamsBytes", "maxControlFrameBytes"]
  ];
  for (const [smaller, larger] of ordered) {
    if (limits[smaller] > limits[larger]) {
      issues.push({
        path: pointer(path, smaller),
        code: "INCONSISTENT_LIMITS",
        message: `${smaller} (${limits[smaller]}) must not exceed ${larger} (${limits[larger]}).`
      });
    }
  }
  // The CONNECT frame carries the token and is bounded by the same transport limit, so a smaller value refuses valid tokens.
  if (limits.maxControlFrameBytes < MIN_CONTROL_FRAME_BYTES) {
    issues.push({
      path: pointer(path, "maxControlFrameBytes"),
      code: "INCONSISTENT_LIMITS",
      message: `maxControlFrameBytes must be at least ${MIN_CONTROL_FRAME_BYTES} so a token of up to ${MAX_TOKEN_BYTES} bytes fits in the connection handshake.`
    });
  }
  if (limits.maxDataFrameBytes < 1_024) {
    issues.push({ path: pointer(path, "maxDataFrameBytes"), code: "INCONSISTENT_LIMITS", message: "maxDataFrameBytes must be at least 1024." });
  }
}
